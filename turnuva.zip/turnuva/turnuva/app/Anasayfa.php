<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Anasayfa extends Model
{
    protected $table = 'anasayfa';
    protected $fillable = ['aciklama'];
}
