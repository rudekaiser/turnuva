<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeGetController extends Controller
{
    public function get_index()
    {
        return view('index');
    }
}
