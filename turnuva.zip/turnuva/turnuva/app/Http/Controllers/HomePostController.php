<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomePostController extends Controller
{
    //
}
